export const demoMixin = {
    data(){
        return{
            name: 'This is user name',
            cars: ['prado','bmw','lamvorgini','pazero']
        }
    }
}