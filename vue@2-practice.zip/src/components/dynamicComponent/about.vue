<template>
  <div>
    <h3>About</h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab culpa dolor est eum eveniet excepturi incidunt libero omnis quibusdam repellat? Eius eum, ipsam. Doloremque esse id laborum rerum ullam vel!</p>
  </div>
</template>

<script>
export default {
  data(){
    return{

    }
  }
}
</script>

<style scoped>

</style>