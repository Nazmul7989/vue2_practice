<template>
  <div class="container">
    <div class="row">
      <div class="col-6">
          <form class="mt-5">
            <div class="row">
              <div class="col-md-3">
                <div class="form-group">
                  <input type="text"  class="form-control" placeholder="Name">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <input type="email" class="form-control" placeholder="Email">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <input type="text"  class="form-control" placeholder="Phone No">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <input type="submit" class="btn btn-primary" value="Send">
                </div>
              </div>
            </div>
          </form>
      </div>
    </div>
  </div>
</template>

<script>
export default {
data(){
  return{

  }
}
}
</script>

<style scoped>

</style>