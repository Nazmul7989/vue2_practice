<template>
<div>
  <h3>Home</h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium ad alias aperiam, blanditiis commodi consectetur error fuga impedit incidunt nulla odio perferendis quae quidem quis sint, suscipit voluptate voluptatum. Cumque!</p>
</div>
</template>

<script>
export default {
  data(){
    return{

    }
  }
}
</script>

<style scoped>

</style>